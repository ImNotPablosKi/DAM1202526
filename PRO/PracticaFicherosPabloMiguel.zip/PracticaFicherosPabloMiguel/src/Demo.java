import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Demo {

    public static void escribirValidos(String registro) {

        try (BufferedWriter bw = new BufferedWriter(new FileWriter("src/usuarios_validos.txt", true))) {

            bw.write(registro);

        } catch (IOException e) {

            System.out.println("Error E/S 2");

        }

    }

    public static void escribirInvalidos(String registro) {

        try (BufferedWriter bw = new BufferedWriter(new FileWriter("src/usuarios_invalidos.txt", true))) {

            bw.write(registro + "\n");

        } catch (IOException e) {

            System.out.println("Error E/S 3");

        }

    }

    public static boolean validarNombre(String line) {

        return Pattern.matches("[a-zA-z]+ [a-zA-Z]+;", line);

    }

    public static boolean validarMail(String line) {

        return Pattern.matches("[a-zA-Z.]+@[a-zA-Z]+\\.[a-z]{2,};", line);

    }

    public static boolean validarTfno(String line) {

        return Pattern.matches("[6789]\\d{8};", line);

    }

    public static boolean validarDni(String line) {

        return Pattern.matches("\\d{8}[A-Z]", line);

    }

    public static void main(String[] args) {

        try (BufferedReader br = new BufferedReader(new FileReader("src/Validar/usuarios.txt"))) {

            String line;

            while ((line = br.readLine()) != null) {

                if (validarDni(line) && validarNombre(line) && validarMail(line) && validarTfno(line)) {

                    escribirValidos(line);

                } else {

                    escribirInvalidos(line);

                }

            }

        } catch (IOException e) {

            System.out.println("Error E/S 1");

        }
    }
}
